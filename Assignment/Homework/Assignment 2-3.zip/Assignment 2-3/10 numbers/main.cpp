/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on July 6, 2015, 1:06 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {
    int num1,
            num2,
            num3,
            num4,
            num5,
            num6,
            num7,
            num8,
            num9,
            num10,
            sum,
            negnum,
            
    
    
    
    

    return 0;
}

