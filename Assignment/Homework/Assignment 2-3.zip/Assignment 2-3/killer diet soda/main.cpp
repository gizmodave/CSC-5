/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on July 5, 2015, 7:43 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

