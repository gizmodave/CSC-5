/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on July 4, 2015, 8:39 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {
    int n;
    float guess,r;
    
    guess = (guess + r) / 2;
    
    cin>>n;
    r = n / guess;
    cout<<"answer ";
    cout<<r<<endl;
    

    return 0;
}

