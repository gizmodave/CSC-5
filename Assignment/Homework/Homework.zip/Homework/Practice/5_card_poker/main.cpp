/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on April 4, 2015, 7:13 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    

    return 0;
}

