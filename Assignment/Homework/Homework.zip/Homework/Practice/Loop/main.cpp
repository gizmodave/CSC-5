/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on March 12, 2015, 9:05 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main() 
{
    int x = 0;
    while (x <10)
    {
        cout << x << endl;
        x++;
    }
       
    return 0;
}

