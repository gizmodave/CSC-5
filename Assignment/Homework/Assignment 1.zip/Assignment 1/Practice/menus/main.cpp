/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on April 7, 2015, 10:24 PM
 */

#include <cstdlib>
#include  <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
 

    return 0;
}

