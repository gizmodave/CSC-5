/* 
 * File:   main.cpp
 * Author: drami_000
 *
 * Created on April 10, 2015, 5:14 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    srand(0(time))
    int ball;
    ball = 1;
    ball = rand() % 200 * 1;
    
    cout << "test: ";
    cin << ball;

    return 0;
}

