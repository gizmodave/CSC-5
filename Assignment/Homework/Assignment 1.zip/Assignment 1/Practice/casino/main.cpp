int row1, row2, row3, row4, row5, row6, row7, row8, row9;
    int pot1, pot2, pot3, pot4, pot5, pot6, pot7, pot8, pot9;