/* 
 * File:   main.cpp
 * Author: David Ramirez
 * Created on June 29, 2015, 2:08 PM
 * Purpose: Homework, Programming projects 2
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"*******************************************************\n\n";
    cout<<"\t    C C C\t       S S S S\t\t!!\n";// line 1
    cout<<"\t  C\t  C\t     S\t       S\t!!\n";// line 2
    cout<<"\t C\t\t    S\t\t\t!!\n";// line 3
    cout<<" \tC\t\t     S\t\t\t!!\n";// line 4
    cout<<"\tC\t\t      S S S S\t\t!!\n";// line 5
    cout<<"\tC\t\t\t       S\t!!\n";// line 6
    cout<<"\t C\t\t\t        S\t!!\n";// line 7
    cout<<"\t  C\t  C\t     S\t       S\n";// line 8
    cout<<"\t    C C C\t       S S S S\t\t00\n\n";// line 9
    cout<<"*******************************************************\n";
    cout<<"\tComputer Science is Cool Stuff!!!";
    return 0;
}

